UPDATE public.users SET role = 'admin' WHERE email = 'xh18888@126.com';
