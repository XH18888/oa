UPDATE public.users SET role = 'admin' WHERE email = 'XH18888@126.com';
